import requests
import time
from requests.auth import HTTPBasicAuth

fixed_numbers = [5, 10, 20, 50, 100]
def format_dicts_as_table(distance, debt):
    # Ensure both dictionaries have the same keys and sort them in ascending order
    keys = sorted(set(distance.keys()).union(debt.keys()))

    # Create the table header
    table = "Key          Distance       Debt\n"
    table += "-" * 35 + "\n"

    # Format each row
    for key in keys:
        dist = distance.get(key, "N/A")  # Use "N/A" if the key is missing
        deb = debt.get(key, "N/A")       # Use "N/A" if the key is missing
        table += f"{key:<12} {dist:<12} {deb}\n"

    return table
def send_whatsapp_alert(to, message):
    account_sid = "AC61d586e93de9cb2448d5f8e8856c31b5"
    auth_token = "81f38f150e4a925131f5226d963be101"
    from_whatsapp = "whatsapp:+14155238886"
    url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"
    data = {
        "To": to,
        "From": from_whatsapp,
        "Body": message
    }
    response = requests.post(url, data=data, auth=HTTPBasicAuth(account_sid, auth_token))
    return response.json()

def load_numbers_from_file(filepath):
    numbers = []
    try:
        with open(filepath, 'r') as file:
            for line in file:
                # Convert each line to a number and append to the list
                numbers.append(float(line.strip().replace(",","")))
    except FileNotFoundError:
        print(f"Error: The file {filepath} was not found.")
    except ValueError as e:
        print(f"Error: Could not convert line to a number. Details: {e}")
    return numbers

def process_numbers_based_on_threshold(numbers):
    thresholds = fixed_numbers
    result = {}
    for threshold in thresholds:
        result[threshold] = threshold/max(1,sum(1 for i in numbers[-(threshold*4):] if i > threshold))
        result[threshold] = round(result[threshold],2)
    return result

def find_distance_to_greater_fixed(numbers):
    result = {}

    for fixed in fixed_numbers:
        found = False
        for j in range(len(numbers) - 1, -1, -1):
            if numbers[j] > fixed:
                # Calculate the distance from the end
                result[fixed] = len(numbers) - j
                found = True
                break
        if not found:
            # If no greater number exists, set the value to -1
            result[fixed] = -1

    return result

def checkForAlert(debt):
    for i in [10,20,50,100]:
        if debt[i] >= i/2:
            return True
    return False 

if __name__ == "__main__":
    while True:
        numbers = load_numbers_from_file("../monitoring/metrics/test.json")
        distance = find_distance_to_greater_fixed(numbers)
        debt = process_numbers_based_on_threshold(numbers)
        isAlert = checkForAlert(debt)
        if isAlert:
            print(f"Sending message {format_dicts_as_table(distance,debt)}")
            response = send_whatsapp_alert("whatsapp:+917744079587", f"{format_dicts_as_table(distance,debt)}")
            print("Function returned True. Sleeping for 10 minutes...")
            time.sleep(10 * 60)  # Sleep for 10 minutes
        else:
            print("Function returned False. Sleeping for 1 minutes...")
            time.sleep(1 * 60)  # Sleep for 10 minutes


