while true; do
    read -p " " line
    echo "$line" | tee -a  monitoring/metrics/test.json > /dev/null
done
