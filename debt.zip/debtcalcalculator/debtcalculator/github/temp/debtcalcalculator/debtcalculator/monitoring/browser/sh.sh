#!/bin/bash

while true; do
  # Check if the new.json file exists
  if [ -f ~/Downloads/new.json ]; then
    # Read the content of new.json and write it to test.json
    cat ~/Downloads/new.json >> ../metrics/test.json
    # Echo the content to test.json
    echo "Moved content from new.json to test.json"
    # Delete the new.json file after moving
    rm ~/Downloads/new.json
  else
    echo "new.json does not exist, skipping..."
  fi
  sleep 5
done
