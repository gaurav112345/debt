from prometheus_client import start_http_server, Gauge
import time

numStream = [2,3,5,10,20,50,100]

latest_value = [Gauge(f'stream_latest_value_{i}', 'Latest integer from the stream') for i in numStream]
streamOfData = []

def monitor_file(file_path):
    """Continuously monitor the file and update the metric."""
    while True:
        streamOfData = refresh_data(file_path)
        for i in range(len(numStream)):
            #print(calculate_debt(numStream[i], streamOfData))
            latest_value[i].set(round(calculate_debt(numStream[i], streamOfData),2))

def refresh_data(file_path):
    polyShape = []
    with open(file_path) as f:
        for line in f:
            decimal_values = [float(value.replace(",", "")) for value in line.split()]
            polyShape.extend(decimal_values)
    streamOfData = polyShape
    return streamOfData

def calculate_debt(num, streamOfData):
    return num/max(1,sum(1 for i in streamOfData[-(num*4):] if i > num))

if __name__ == "__main__":
    start_http_server(8000)
    print(refresh_data('metrics/test.json'))
    #print(calculate_debt(5))
    #print(calculate_debt(10))
    print("Exporter running on http://localhost:8000/metrics")
    file_path = "metrics/test.json"
    monitor_file(file_path)
