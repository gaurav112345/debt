let val = document.querySelector('.wrap.svelte-160qhws').children[0].children[0].children[0].textContent.slice(0, -1);  // Initial value

setInterval(() => {
  let newval = document.querySelector('.wrap.svelte-160qhws').children[0].children[0].children[0].textContent.slice(0, -1);

  if (newval !== val) {
    val = newval;
    console.log(val);

    // Prepare the data to be written to the file (just the new value)
    let fileData = newval + '\n'; // Just store the new value with a newline

    // Create a Blob from the data (in plain text format)
    const blob = new Blob([fileData], { type: 'text/plain' });

    // Create a download link and trigger the download
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'new.json'; // The filename for the download
    link.click();
  }
}, 10000);  // Run every 10 seconds
